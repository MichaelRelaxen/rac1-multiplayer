#include "rc1.h"
#include "common.h"

#include <lib/memory.h>
#include <netex/net.h>
#include <sysutil/sysutil_gamecontent.h>

#include <cell/cell_fs.h>

#include <rc1/Game.h>
#include "rc1/multiplayer/network/Packet.h"
#include "multiplayer/SyncedMoby.h"
#include "multiplayer/Moby/RatchetAttachmentMoby.h"
#include "rc1/multiplayer/Player.h"

#include "bridging.h"

bool use_custom_player_color = false;
uint32_t custom_player_color = 0;
EnableCommunicationsFlags enable_communication_bitmap = (EnableCommunicationsFlags)(
        ENABLE_ON_GET_BOLTS | ENABLE_ON_PICKUP_GOLD_BOLT | ENABLE_ON_UNLOCK_ITEM | ENABLE_ON_UNLOCK_LEVEL
);


extern "C" {
void game_tick() {
    _c_game_tick();
}

SHK_HOOK(void, game_loop_start);
void game_loop_start_hook() {
    if (current_planet != 0 || ratchet_moby != 0) {
        game_tick();
    }

    SHK_CALL_HOOK(game_loop_start);
}

SHK_HOOK(void, game_loop_intro_start);
void game_loop_intro_start_hook() {
    game_tick();

    SHK_CALL_HOOK(game_loop_intro_start);
}

SHK_HOOK(void, _start_in_level_movie, u32);
void _start_in_level_movie_hook(u32 movie) {
    if (!(enable_communication_bitmap & ENABLE_ON_START_IN_LEVEL_MOVIE)) {
        start_in_level_movie(movie);
    }

    Client *client = Game::shared().client();
    if (client != nullptr) {
        Packet *packet = Packet::make_start_in_level_movie_packet(movie);
        client->make_ack(packet, nullptr);
        client->send(packet);
    }
}

void start_in_level_movie(u32 movie) {
    SHK_CALL_HOOK(_start_in_level_movie, movie);
}

SHK_HOOK(void, on_respawn);
void on_respawn_hook() {
    SHK_CALL_HOOK(on_respawn);
    _c_on_respawn();
}

SHK_HOOK(void, STUB_0006544c);
void STUB_0006544c_hook(Moby *moby) {
    _c_moby_update(moby);
}

static int resets = 0;

// Hook to avoid some consoles getting a "game is corrupted, restart the game" on game start
// I think maybe it makes trophies not work?
SHK_HOOK(void, authenticate_game);
void authenticate_game_hook() {
    MULTI_LOG("Game totally authenticated\n");

    if (resets > 0) {
        _c_game_reset();
    }

    resets += 1;
}

SHK_HOOK(void, FUN_000784e8);
void FUN_000784e8_hook() {
    _c_game_render();

    SHK_CALL_HOOK(FUN_000784e8);
}

SHK_HOOK(void, bink_do_frame, u32, u32);
void bink_do_frame_hook(u32 param_1, u32 param_2) {
    SHK_CALL_HOOK(bink_do_frame, param_1, param_2);

    _c_bink_do_frame();
}


SHK_HOOK(void, perform_save_action, void*, int, void*);
void perform_save_action_hook(void* ptr1, int action, void* ptr2) {
    _c_on_save_operation(action, ptr2);
}

SHK_HOOK(void, wrench_update_func, Moby *);
void wrench_update_func_hook(Moby *moby) {
    SHK_CALL_HOOK(wrench_update_func, moby);
}

SHK_HOOK(int, cellGameBootCheck, unsigned int*, unsigned int*, CellGameContentSize*, char*);
int cellGameBootCheckHook(unsigned int* type, unsigned int* attributes, CellGameContentSize* size, char* dirName) {
    MULTI_LOG("Type: %p, attr: %p, size: %p, dirName: %p\n", type, attributes, size, dirName);

    *type = 2;
    *attributes = 0;
    size->hddFreeSizeKB = 10000;
    size->sizeKB = -1;
    size->sysSizeKB = 4;

    int fd;
    const char* src;
    // Manually copying the string
    // Check if digital version exists and use that. Otherwise fall back to disc. If no disc then we just crash
    CellFsErrno ebootStat = cellFsOpendir("/dev_hdd0/game/NPEA00385/", &fd);
    if (ebootStat == CELL_FS_ENOENT) {
        if (cellFsOpendir("/dev_hdd0/game/NPUA80643/", &fd) == CELL_FS_ENOENT) {
            src = "BCES01503";
        } else {
            src = "NPUA80643";
        }
    } else {
        src = "NPEA00385";
    }
    while (*src) {
        *dirName = *src;
        dirName++;
        src++;
    }
    *dirName = '\0';  // Null terminate the string

    MULTI_LOG("Done the thing\n");

    return 0;
}

SHK_HOOK(int, cellGameContentPermit, char*, char*);
int cellGameContentPermitHook(char* contentInfoPath, char* usrdirPath) {
    MULTI_LOG("contentInfoPath: %p, usrdirPath: %p\n", contentInfoPath, usrdirPath);

    int fd;
    const char *src;

    // Check if digital version exists and use that. Otherwise fall back to disc. If no disc then we just crash
    CellFsErrno ebootStat = cellFsOpendir("/dev_hdd0/game/NPEA00385/", &fd);
    if (ebootStat == CELL_FS_ENOENT) {
        if (cellFsOpendir("/dev_hdd0/game/BCES01503/", &fd) == CELL_FS_ENOENT) {
            if (cellFsOpendir("/dev_hdd0/game/NPUA80643/", &fd) == CELL_FS_ENOENT) {
                src = "/dev_bdvd/PS3_GAME";
            } else {
                src = "/dev_hdd0/game/NPUA80643";
            }
        } else {
            src = "/dev_hdd0/game/BCES01503";
        }
    } else {
        src = "/dev_hdd0/game/NPEA00385";
    }

    int len = 0;

    while (*src) {
        *contentInfoPath = *src;
        contentInfoPath++;
        src++;
        len+=1;
    }
    *contentInfoPath = '\0';  // Null terminate the string

    const char *usrdirStr = "/USRDIR";

    src -= len;

    while (*src) {
        *usrdirPath = *src;
        usrdirPath++;
        src++;
    }

    while (*usrdirStr) {
        *usrdirPath = *usrdirStr;
        usrdirPath++;
        usrdirStr++;
    }

    *usrdirPath = '\0';  // Null terminate the string

    MULTI_LOG("Done the thing\n");

    return 0;
}

#include "rc1/game/GoldBolt.h"

SHK_HOOK(void, goldBoltUpdate, Moby* moby);
void goldBoltUpdateHook(Moby* moby) {
    ((GoldBolt*)moby)->update();
}



// Hook the item_unlock function
SHK_HOOK(void, _unlock_item, int, uint8_t);
void _unlock_item_hook(int item_id, uint8_t equip) {
    proxy_item_array[item_id] = true;
    if (!(enable_communication_bitmap & ENABLE_ON_UNLOCK_ITEM)) {
        MULTI_LOG("unlock_item communication disabled. acting autonomously.\n");
        unlock_item(item_id, equip);
    }
    Client *client = Game::shared().client();
    if (client != nullptr) {
        Packet *packet = Packet::make_unlock_item_packet(item_id, equip);
        client->make_ack(packet, nullptr);
        client->send(packet);
    }
}

// Make original unlock_item available to our code
void unlock_item(int item_id, uint8_t equip) {
    switch(item_id) {
        case 0x30: // Zoomerator
            *((bool*)0x96bff0) = true;
            break;
        case 0x31: // Raritanium
            *((bool*)0x96bff1) = true;
            break;
        case 0x32: // Codebot
            *((bool*)0x96bff2) = true;
            break;
        case 0x34: // Premium Nanotech
            *((bool*)0x96bff4) = true;
            break;
        case 0x35: // Ultra Nanotech
            *((bool*)0x96bff5) = true;
            break;
        default:
            SHK_CALL_HOOK(_unlock_item, item_id, equip);
            break;
    }

    // We can safely call the reload function outside of the vendor, but we don't want to call it if the player is
    //   currently using the PDA.
    if (last_vendor_was_pda == 0) {
        reload_gadgetron_vendor_items(0);
    }
}

SHK_HOOK(void, _unlock_level, int);
void _unlock_level_hook(int level) {
    proxy_level_array[level] = true; // Ensure the level is unlocked locally as well
    if (!(enable_communication_bitmap & ENABLE_ON_UNLOCK_LEVEL)) {
        MULTI_LOG("unlock_level communication disabled. acting autonomously.\n");
        unlock_level(level);
    }
    Client *client = Game::shared().client();
    if (client != nullptr) {
        Packet *packet = Packet::make_unlock_level_packet(level);
        client->make_ack(packet, nullptr);
        client->send(packet);
    }
}

void unlock_level(int level) {
    SHK_CALL_HOOK(_unlock_level, level);
}

SHK_HOOK(void, _unlock_skillpoint, u8);
void _unlock_skillpoint_hook(u8 skillpoint) {
    Client *client = Game::shared().client();
    if (client != nullptr) {
        Packet *packet = Packet::make_unlock_skillpoint_packet(skillpoint);
        client->make_ack(packet, nullptr);
        client->send(packet);
    }
}

void unlock_skillpoint(u8 skillpoint) {
    SHK_CALL_HOOK(_unlock_skillpoint, skillpoint);
}

SHK_HOOK(void, metal_detector_spot_update_func, Moby*);
void metal_detector_spot_update_func_hook(Moby* moby) {
    if (moby->state == 0) {
        struct MetalDetectorSpotVars *vars = (struct MetalDetectorSpotVars *)(moby->vars);

        vars->bolts = vars->bolts * *metal_detector_bolt_multiplier;
    }

    SHK_CALL_HOOK(metal_detector_spot_update_func, moby);
}

SHK_HOOK(void, menu_item_tick, MenuItem*);
void menu_item_tick_hook(MenuItem* menu_item) {
    SHK_CALL_HOOK(menu_item_tick, menu_item);
}

SHK_HOOK(void, set_ratchet_animation, u32 animation_id, char animation_frame);
void set_ratchet_animation_hook(u32 animation_id, char animation_frame) {
    // Get PowerPC f1 register using inline assembly because SHK_HOOK doesn't properly work with float parameters
    // This is the duration of the animation
    volatile double duration;
    asm volatile("stfd 1, %0" : "=m"(duration));

    if (current_planet == 15 && animation_id == 0x5f) {
        return;
    }

    SHK_CALL_HOOK(set_ratchet_animation, animation_id, animation_frame);

    _c_set_ratchet_animation_duration((int)duration);
}

SHK_HOOK(Moby*, _spawn_moby, u16 o_class);
Moby* spawn_moby_hook(u16 o_class) {
    Moby* moby = SHK_CALL_HOOK(_spawn_moby, o_class);

    if (moby == nullptr) {
        return nullptr;
    }

    if (game_state == Menu) {
        return moby;
    }

    switch(moby->o_class) {
        // Weapons and projectiles
        case 121: // Bomb glove bomb
        case 0xcb: // Decoy
        case 0xac: // Visibomb missile
        case 0x1df: // Drone
        case 0x99: // Gold devastator missile
        case 0x71a: // Sandmouse
        case 0x4a: // Mine
        case 0xba: // Doom bot
        case 457:  // RYNO missile
        case 270: // Chicken
        case 428: // Feather (from killing chickens)
            SyncedMoby::make_synced_moby(moby)->activate();
            break;
        case 601: // Clank Backpack
            Player::shared().backpack_moby = RatchetAttachmentMoby::make_synced_moby(moby, 5, 5);
            if (remove_clank_backpack == 0) {
                Player::shared().backpack_moby->activate();
            }
            break;
        case 607: // Heli pack
        case 608: // Thruster pack
        case 609: // Hydro pack
            Player::shared().backpack_attachment_moby = RatchetAttachmentMoby::make_synced_moby(moby, 5, 5);
            if (remove_clank_backpack == 0) {
                Player::shared().backpack_attachment_moby->activate();
            }
            break;
        case 1289: // O2 Mask
        case 1290: // Pilots helmet
        case 433:  // Sonic summoner
            Player::shared().helmet_moby = RatchetAttachmentMoby::make_synced_moby(moby, 4, 21);
            Player::shared().helmet_moby->activate();
            break;
//        case 407:  // Persuader
//            Player::shared().persuader_moby = RatchetAttachmentMoby::make_synced_moby(moby, 5, 5);
//        case 614:  // Map-o-matic
//            Player::shared().map_o_matic_moby = RatchetAttachmentMoby::make_synced_moby(moby, 5, 5);
//            Player::shared().map_o_matic_moby->activate();
//            break;
//        case 618:  // Bolt magnetizer
//            Player::shared().bolt_magnetizer_moby = RatchetAttachmentMoby::make_synced_moby(moby, 5, 5);
//            Player::shared().bolt_magnetizer_moby->activate();
//            break;
//        case 173:  // Magneboots
//        case 195:  // Grindboots
//            if (Player::shared().left_shoe_moby == nullptr || Player::shared().left_shoe_moby->o_class != o_class) {
//                Player::shared().left_shoe_moby = RatchetAttachmentMoby::make_synced_moby(moby, 22, 22);
//                Player::shared().left_shoe_moby->activate();
//            } else if (Player::shared().right_shoe_moby == nullptr || Player::shared().right_shoe_moby->o_class != o_class) {
//                Player::shared().right_shoe_moby = RatchetAttachmentMoby::make_synced_moby(moby, 23, 23);
//                Player::shared().right_shoe_moby->activate();
//            }
//            break;
    }

    return moby;
}

Moby* spawn_moby(u16 o_class) {
    return SHK_CALL_HOOK(_spawn_moby, o_class);
}

SHK_HOOK(struct Damage*, _moby_get_damage, Moby*, u32, u32);
struct Damage* _moby_get_damage_hook(Moby* moby, u32 flags, u32 unk) {
    struct Damage* damage = SHK_CALL_HOOK(_moby_get_damage, moby, flags, unk);

    return damage;
}

SHK_HOOK(u64, init_gameplay);
u64 init_gameplay_hook() {
    _c_before_init_gameplay();

    u64 ret = SHK_CALL_HOOK(init_gameplay);

    _c_after_init_gameplay();

    return ret;
}

struct Damage* moby_get_damage(Moby* moby, u32 flags, u32 unk) {
    return SHK_CALL_HOOK(_moby_get_damage, moby, flags, unk);
}

void draw_text_opt(TextOpt* text_opt, Color color, char* text, ssize_t len, float text_size) {
    // Set float with PowerPC assembly due to the lack of float support in the SHK_FUNCTION_DEFINE_STATIC_4 macro
    asm volatile("lfs 1, %0" : : "m"(text_size));

    _draw_text_opt(text_opt, color.to_u32(), text, len);
}

int custom_item(int id) {
	if(id == 0x24) return 117; // ZOOMERATOR
	if(id == 0x25) return 118; // RARITANIUM
	if(id == 0x26) return 119; // CODEBOT
	if(id == 0x27) return 120; // PERSUADER
	if(id == 0x28) return 123; // PREMIUM NANOTECH
	if(id == 0x29) return 124; // ULTRA NANOTECH
	if(id == 0x2a) return 10;  // BOLT
	if(id == 0x2b) return 134; // FISH   
	if(id == 0x2c) return 217; // Infobot
	if(id == 0x2d) return 215;
	return 0;
}

SHK_HOOK(int, vendorhack_icon_loop, uint16_t, int);
int vendorhack_icon_loop_hook(uint16_t id, int mode) {
    register int r29 asm("r29");
    int i = r29;

    if (i >= 0 && i < vendorItemsCount) {
        int item = vendorItems[i].weaponId;
        if (item >= 0x24) {
            return custom_item(item);
        }
    }

    return lookup_icon_texture(id, mode);
}

SHK_HOOK(int, vendorhack_icon_scroll, uint16_t, int);
int vendorhack_icon_scroll_hook(uint16_t id, int mode) {
    register int r29 asm("r29");
    int i = r29;

    int weapon_idx = vendorItemsCount * 2 + i + vendorSelectedIndex + -3;
    weapon_idx -= (weapon_idx / vendorItemsCount) * vendorItemsCount;

    int item = vendorItems[weapon_idx].weaponId;
    if (item >= 0x24) {
        return custom_item(item);
    }
    
    return lookup_icon_texture(id, mode);
}

SHK_HOOK(char*, vendorhack_item_string, int);
char* vendorhack_item_string_hook(int id) {
    int item = vendorItems[vendorSelectedIndex].weaponId;
    if(item == 0x24) id = 0x4E74; // ZOOMERATOR
    if(item == 0x25) id = 0x4E75; // RARITANIUM
    if(item == 0x26) id = 0x4E77; // CODEBOT
    if(item == 0x27) id = 0x4E73; // PERSUADER
    if(item == 0x28) id = 0x4E71; // PREMIUM NANOTECH
    if(item == 0x29) id = 0x4E72; // ULTRA NANOTECH
    if(item == 0x2A) id = 0x4E9F; // BOLT
    if(item == 0x2C) id = 0x4E7C; // Infobot
    return get_ui_string(id);
}


void rc1_init() {
    MULTI_LOG("Multiplayer initializing.\n");

    SHK_BIND_HOOK(STUB_0006544c, STUB_0006544c_hook);  // Used as a "trampoline" to our custom Moby update func
    SHK_BIND_HOOK(game_loop_start, game_loop_start_hook);
    SHK_BIND_HOOK(game_loop_intro_start, game_loop_intro_start_hook);
    SHK_BIND_HOOK(wrench_update_func, wrench_update_func_hook);
    SHK_BIND_HOOK(authenticate_game, authenticate_game_hook);
    SHK_BIND_HOOK(FUN_000784e8, FUN_000784e8_hook);
    SHK_BIND_HOOK(_start_in_level_movie, _start_in_level_movie_hook);
    SHK_BIND_HOOK(on_respawn, on_respawn_hook);
    SHK_BIND_HOOK(cellGameBootCheck, cellGameBootCheckHook);
    SHK_BIND_HOOK(cellGameContentPermit, cellGameContentPermitHook);
    SHK_BIND_HOOK(goldBoltUpdate, goldBoltUpdateHook);
    SHK_BIND_HOOK(_unlock_item, _unlock_item_hook);
    SHK_BIND_HOOK(_unlock_level, _unlock_level_hook);
    SHK_BIND_HOOK(_unlock_skillpoint, _unlock_skillpoint_hook);
    SHK_BIND_HOOK(menu_item_tick, menu_item_tick_hook);
    SHK_BIND_HOOK(set_ratchet_animation, set_ratchet_animation_hook);
    SHK_BIND_HOOK(_spawn_moby, spawn_moby_hook);
    SHK_BIND_HOOK(_moby_get_damage, _moby_get_damage_hook);
    SHK_BIND_HOOK(metal_detector_spot_update_func, metal_detector_spot_update_func_hook);
    SHK_BIND_HOOK(bink_do_frame, bink_do_frame_hook);
    SHK_BIND_HOOK(perform_save_action, perform_save_action_hook);
    SHK_BIND_HOOK(init_gameplay, init_gameplay_hook);
    SHK_BIND_HOOK(vendorhack_icon_loop, vendorhack_icon_loop_hook);
    SHK_BIND_HOOK(vendorhack_icon_scroll, vendorhack_icon_scroll_hook);
    SHK_BIND_HOOK(vendorhack_item_string, vendorhack_item_string_hook);

    MULTI_LOG("Bound hooks\n");
}

void rc1_shutdown() {
    sys_net_finalize_network();
}

};